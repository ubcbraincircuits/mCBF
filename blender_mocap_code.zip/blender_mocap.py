
import bpy
import math
import random
import numpy as np
import sys, os
import mathutils
import numpy as np
import math
from scipy.spatial.transform import Rotation as R




data_home_path = r'datapath' #'\datapath/13'
amc_name = 'nameofamcfile' #'13_39' #for jump
motions = np.load(data_home_path +os.sep +'motion_'+amc_name+'.npy',allow_pickle = True)
joints_dof = np.load(data_home_path +os.sep+'joints_dof_'+amc_name+'.npy',allow_pickle = True)
joints_dof = joints_dof.item()
joints_direction = np.load(data_home_path +os.sep+'joints_direction_'+ amc_name+'.npy',allow_pickle = True)
joints_direction = joints_direction.item()
movement_direction = np.load(data_home_path +os.sep+'movement_direction_'+ amc_name+'.npy',allow_pickle = True)
movement_direction = movement_direction.item()
translation_root = np.load(data_home_path +os.sep+'translation_root_'+ amc_name+'.npy',allow_pickle = True)
translation_root = translation_root.item()






## 1. Get length of each bone
def GetBoneLength(ob):
    bone_length={}
    for bone in ob.pose.bones:
        bone_length[bone.name] = bone.length
    return bone_length

## 2. control the movement of each bone iteratively.
def MovementBone(ob,bones_length,frame_num):
    # the utility of this function is to read the necessary infromation about each bones
    # and then call a function called rotate_bones to control the movement of bone based on those informtion
    for p in range(5):
        if p ==0: # control the trunk of mouse. you may need to revise the parts_name based on your skeleton
            for q in range(3):
                if q ==0:
                    parts_name = 'lumbar_vertebrae_1'
                    direction = np.array(movement_direction[frame_num,'lowerback'])
                elif q ==1:
                    parts_name = 'lumbar_vertebrae_2'
                    direction = np.array(movement_direction[frame_num,'upperback'])
                elif q ==2:
                    parts_name = 'lumbar_vertebrae_3'
                    direction = np.array(movement_direction[frame_num,'thorax'])
                elif q ==3:
                    parts_name = 'thoracic_vertebrae_1'
                    direction = np.array(movement_direction[frame_num,'lowerneck'])
                elif q ==4:
                    parts_name = 'thoracic_vertebrae_2'
                    direction = np.array(movement_direction[frame_num,'upperneck'])
                elif q ==5:
                    parts_name = 'skull'
                    direction = np.array(movement_direction[frame_num,'head'])
                rotate_bones(ob,parts_name,direction,bones_length[parts_name],frame_num)
        elif p ==1: # control the right forelimb of mouse.
            for q in range(4):
                if q == 0:
                    parts_name = 'scapula_r'
                    direction = np.array(movement_direction[frame_num,'rclavicle'])
                elif q ==1:
                    parts_name = 'humerus_r'
                    direction = np.array(movement_direction[frame_num,'rhumerus'])
                elif q==2:
                    parts_name = 'ulna_r'
                    direction = np.array(movement_direction[frame_num,'rradius'])
                elif q==3:
                    parts_name = 'fore_paw_r'
                    direction = np.array(movement_direction[frame_num,'rwrist'])
                rotate_bones(ob,parts_name,direction,bones_length[parts_name],frame_num)
        elif p ==2: # control the left forelimb of mouse.
            for q in range(4):
                if q == 0:
                    parts_name = 'scapula_l'
                    direction = np.array(movement_direction[frame_num,'lclavicle'])
                elif q ==1 :
                    parts_name = 'humerus_l'
                    direction = np.array(movement_direction[frame_num,'lhumerus'])
                elif q==2:
                    parts_name = 'ulna_l'
                    direction = np.array(movement_direction[frame_num,'lradius'])
                elif q==3:
                    parts_name = 'fore_paw_l'
                    direction = np.array(movement_direction[frame_num,'lwrist'])
                rotate_bones(ob,parts_name,direction,bones_length[parts_name],frame_num)
        elif p ==3:   # control the right hindlimb of mouse.
            for q in range(4):
                if q==0:
                    parts_name = 'perlvis_r'
                    direction = np.array(movement_direction[frame_num,'rhipjoint'])
                if q==1:
                    parts_name = 'femur_r'
                    direction = np.array(movement_direction[frame_num,'rfemur'])
                elif q==2:
                    parts_name = 'tibia_r'
                    direction = np.array(movement_direction[frame_num,'rtibia'])
                elif q==3:
                    parts_name = 'hind_paw_r'
                    direction = np.array(movement_direction[frame_num,'rfoot'])
                rotate_bones(ob,parts_name,direction,bones_length[parts_name],frame_num)
        elif p == 4: #  control the left hindlimb of mouse.
            for q in range(4):
                if  q ==0:
                    parts_name = 'perlvis_l'
                    direction = np.array(movement_direction[frame_num,'lhipjoint'])
                elif q ==1 :
                    parts_name = 'femur_l'
                    direction = np.array(movement_direction[frame_num,'lfemur'])
                elif q==2:
                    parts_name = 'tibia_l'
                    direction = np.array(movement_direction[frame_num,'ltibia'])
                elif q==3:
                    parts_name = 'hind_paw_l'
                    direction = np.array(movement_direction[frame_num,'lfoot'])
                rotate_bones(ob,parts_name,direction,bones_length[parts_name],frame_num)

## 2. control the movement of each bone iteratively.
def rotate_bones(ob,parts_name,direction,bones_length,frame_num):
    parts=ob.pose.bones[parts_name]
    dest_vector = mathutils.Vector((direction)).normalized()
    ori_vector = parts.vector.normalized()
    Matrix_inverse =  np.linalg.inv(parts.matrix)
    Matrix_inverse = Matrix_inverse[0:-1,0:-1]
    dest_vector_local = np.dot(Matrix_inverse,dest_vector) # find destination vector in lacel cordinates
    if parts_name in ['femur_r', 'tibia_r','hind_paw_r','femur_l', 'tibia_l','hind_paw_l']:
        R_matrix = rotation_matrix_Y0(mathutils.Vector((0,1,0)),dest_vector_local)
    else:
        R_matrix = rotation_matrix(mathutils.Vector((0,1,0)),dest_vector_local)
    r_quaternion = mathutils.Matrix(R_matrix).to_quaternion() # from matrix to quaternion
    bpy.context.view_layer.objects.active = ob #choose the object
    bpy.ops.object.mode_set(mode='POSE') #change to pose mode
    parts.rotation_mode = 'QUATERNION' # I use the quaternion
    parts.rotation_quaternion = r_quaternion
    bpy.context.view_layer.update() # impoartant, update the state of model
    parts.keyframe_insert(data_path="rotation_quaternion" ,frame=frame_num) # insert key frame in animation.


def rotation_matrix_Y0(A,B):
# a and b are in the form of numpy array
#from A to B while keeping Y==0
# inputs： vectorA,vectorB
# ouput : rotation matix R

    s1 = B[2]
    X = math.asin(s1)
    c1 = math.cos(X)
    Z = math.atan2(-B[0],B[1])
    Y= 0
    r = mathutils.Euler((X,Y,Z),'XYZ')
    R = r.to_matrix()

    return(R)


def rotation_matrix(A,B):
# a and b are in the form of numpy array
#from A to B
# inputs： vectorA,vectorB
# ouput : rotation matix R
# using Rodrigues rotation formula

   ax = A[0]
   ay = A[1]
   az = A[2]
   bx = B[0]
   by = B[1]
   bz = B[2]
   au = A/(np.sqrt(ax*ax + ay*ay + az*az)) # normalize a
   bu = B/(np.sqrt(bx*bx + by*by + bz*bz)) # normalize b
   theta = np.arccos(au.dot(bu)) # angle between A and B
   c = np.array([ au[1]*bu[2] - au[2]*bu[1] , au[2]*bu[0] - au[0]*bu[2] , au[0]*bu[1] - au[1]*bu[0] ])
   c= c/np.linalg.norm(c)
   wx = c[0]
   wy = c[1]
   wz = c[2]
   cos_theta = np.cos(theta)
   sin_theta = np.sin(theta)
   R = np.array([
   [cos_theta + (wx**2) * (1-cos_theta), wx * wy * (1-cos_theta) - wz * sin_theta, wy*sin_theta +  wx*wz*(1-cos_theta)],
   [wz * sin_theta + wx * wy * (1-cos_theta), cos_theta + (wy**2) * (1-cos_theta),  -wx*sin_theta + wy*wz*(1-cos_theta)],
   [-wy*sin_theta + wx*wz*(1-cos_theta) , wx*sin_theta + wy*wz*(1-cos_theta), cos_theta + (wz**2)*(1-cos_theta)]])
   return(R)

# Checks if a matrix is a valid rotation matrix.
def isRotationMatrix(R) :
    Rt = np.transpose(R)
    shouldBeIdentity = np.dot(Rt, R)
    I = np.identity(3, dtype = R.dtype)
    n = np.linalg.norm(I - shouldBeIdentity)
    return n < 1e-6


# add transltion to the animation
def translation_body(ob, frame_index):
    constant1= 20 # you should choose an proper constant
    parts=ob.pose.bones['root']
    tem = (translation_root[frame_index] - translation_root[0])/constant1
    parts.location = [-tem[0],-tem[2],-tem[1]]
    parts.keyframe_insert("location", frame=frame_index)


print('-------------------------------------------------------')
print('New session start')

ob = bpy.data.objects['c57_bl6_rig']
ob.animation_data_clear() # delete all animation
bpy.ops.pose.rot_clear() # restore all rotation
bones_length = GetBoneLength(ob)
#initiateBone(ob,bones_length,0) # translate the original skeleton to the initial pose for mocap skeleton.

frame_num = np.array(motions).shape[0] # get the length of movement from mocap data.
for frame_index in range(0,frame_num-1,1):
    print(frame_index,'/',frame_num)
    bpy.ops.pose.rot_clear() # reset to default pose
    MovementBone(ob,bones_length,frame_index)
    translation_body(ob, frame_index)
