import os, sys
sys.path.append('AMCParser')
import amc_parser as amc
import AMC3Dviewer as reviwer3d
#%matplotlib inline
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D

# initialization
data_path = r'C:\Users\Giles\Desktop\blender_code\data'
asf_path = r'data\13.asf'
amc_home_path = r'data'
amc_name = '13_39'#'02_01' #'14_06'#'14_14'
amc_path =amc_home_path +os.sep+amc_name+ '.amc'

joints = amc.parse_asf(asf_path)
motions = amc.parse_amc(amc_path)
# save
# save for blender script
np.save(amc_home_path+os.sep+'motion_'+amc_name+'.npy',motions)

# save translation
translation_root = {}
for frame_num in range(0, len(motions), 1):
    joints['root'].set_motion(motions[frame_num])
    translation_root[frame_num] = joints['root'].coordinate
np.save(amc_home_path+os.sep+'translation_root_'+amc_name+'.npy',translation_root)


# save joints_dof
joints_dof={}
for k, v in motions[0].items():
    if k != 'root':
        joints_dof[k] = joints[k].dof
np.save(amc_home_path+os.sep+'joints_dof_'+amc_name+'.npy',joints_dof)

#save joint direction
joints_direction={}
for k, v in joints.items():
    joints_direction[k] = joints[k].direction
np.save(amc_home_path+os.sep+'joints_direction_'+amc_name+'.npy',joints_direction)
# save movement direction
movement_direction = {}
for i in range(0, len(motions), 1):
    joints['root'].set_motion(motions[i])
    for k, v in joints.items():
        if not (joints[k].parent is None):
            movement_direction[i,k] = joints[k].coordinate - joints[k].parent.coordinate

np.save(amc_home_path+os.sep+'movement_direction_'+amc_name+'.npy',movement_direction)
