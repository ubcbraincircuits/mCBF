please use pip install the dependencies in requirements.txt
you also need to install scipy for blender��
https://blender.stackexchange.com/questions/56011/how-to-install-pip-for-blenders-bundled-python
and put the context in blender_mocap.py into blender script